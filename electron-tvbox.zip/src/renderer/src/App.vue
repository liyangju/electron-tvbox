<template>
  <Ua></Ua>
  <Update></Update>
</template>
<script setup>
import Ua from './components/Ua.vue'

import Update from './components/Update.vue'
</script>
<style lang="less">
@import './assets/css/styles.less';
</style>
